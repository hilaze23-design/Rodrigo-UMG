using Microsoft.AspNetCore.Components.Forms;

namespace ClientesBlazor.Services;

/// <summary>
/// Hace que los formularios de Blazor usen las clases de validación de Bootstrap
/// (is-valid / is-invalid) en lugar de las clases propias de Blazor (valid / invalid).
/// Así se muestran los bordes verde/rojo y los mensajes .invalid-feedback de Bootstrap.
/// </summary>
public class BootstrapFieldCssClassProvider : FieldCssClassProvider
{
    public override string GetFieldCssClass(EditContext editContext, in FieldIdentifier fieldIdentifier)
    {
        var esValido = !editContext.GetValidationMessages(fieldIdentifier).Any();

        // Solo marcamos el campo cuando el usuario ya lo tocó o intentó guardar
        if (!editContext.IsModified(fieldIdentifier) && esValido)
            return string.Empty;

        return esValido ? "is-valid" : "is-invalid";
    }
}
