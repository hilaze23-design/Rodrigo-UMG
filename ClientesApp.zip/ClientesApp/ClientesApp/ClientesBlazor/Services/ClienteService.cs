using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using ClientesBlazor.Models;

namespace ClientesBlazor.Services;

/// <summary>
/// Consume la API REST "ClientesApi" (Tarea .NET). La aplicación Blazor NUNCA toca la base de datos:
/// todo pasa por estas llamadas HTTP.
///
///   GET    api/Clientes          -> lista de clientes             (200)
///   GET    api/Clientes/{id}     -> un cliente                    (200, 404)
///   POST   api/Clientes          -> crear                         (201, 400, 409)
///   PUT    api/Clientes/{id}     -> modificar                     (204, 400, 404, 409)
///   DELETE api/Clientes/{id}     -> eliminar                      (204, 404)
/// </summary>
public class ClienteService
{
    /// <summary>
    /// La API usa PropertyNamingPolicy = null, es decir, el JSON lleva los nombres tal cual
    /// (Id_cliente, CUI, NIT, Fecha_Nacimiento...). Aquí se usa la misma configuración.
    /// </summary>
    private static readonly JsonSerializerOptions JsonApi = new(JsonSerializerDefaults.Web)
    {
        PropertyNamingPolicy = null,
        PropertyNameCaseInsensitive = true
    };

    private readonly HttpClient _http;
    private readonly string _endpoint;

    public ClienteService(HttpClient http, IConfiguration config)
    {
        _http = http;
        _endpoint = (config["ApiSettings:ClientesEndpoint"] ?? "api/Clientes").Trim('/');
    }

    public async Task<List<Cliente>> ObtenerTodosAsync()
    {
        var respuesta = await EnviarAsync(() => _http.GetAsync(_endpoint));
        await VerificarAsync(respuesta);
        return await respuesta.Content.ReadFromJsonAsync<List<Cliente>>(JsonApi) ?? new List<Cliente>();
    }

    public async Task<Cliente?> ObtenerPorIdAsync(int id)
    {
        var respuesta = await EnviarAsync(() => _http.GetAsync($"{_endpoint}/{id}"));
        if (respuesta.StatusCode == HttpStatusCode.NotFound) return null;
        await VerificarAsync(respuesta);
        return await respuesta.Content.ReadFromJsonAsync<Cliente>(JsonApi);
    }

    public async Task CrearAsync(Cliente cliente)
    {
        cliente.Id_cliente = 0; // La base de datos genera el Id (IDENTITY)
        var respuesta = await EnviarAsync(() => _http.PostAsJsonAsync(_endpoint, cliente, JsonApi));
        await VerificarAsync(respuesta);
    }

    public async Task ActualizarAsync(Cliente cliente)
    {
        var respuesta = await EnviarAsync(() =>
            _http.PutAsJsonAsync($"{_endpoint}/{cliente.Id_cliente}", cliente, JsonApi));
        await VerificarAsync(respuesta);
    }

    public async Task EliminarAsync(int id)
    {
        var respuesta = await EnviarAsync(() => _http.DeleteAsync($"{_endpoint}/{id}"));
        await VerificarAsync(respuesta);
    }

    // ---------------- Manejo de errores ----------------

    private async Task<HttpResponseMessage> EnviarAsync(Func<Task<HttpResponseMessage>> llamada)
    {
        try
        {
            return await llamada();
        }
        catch (HttpRequestException ex)
        {
            throw new ApiException(
                $"No se pudo conectar con la API ({_http.BaseAddress}). " +
                "Verifica que el proyecto ClientesApi esté en ejecución y que la URL en appsettings.json sea correcta. " +
                $"Detalle: {ex.Message}");
        }
        catch (TaskCanceledException)
        {
            throw new ApiException("La API tardó demasiado en responder. Intenta de nuevo.");
        }
    }

    private static async Task VerificarAsync(HttpResponseMessage respuesta)
    {
        if (respuesta.IsSuccessStatusCode) return;

        var (detalle, errores) = await LeerErrorAsync(respuesta);

        // La API devuelve 409 cuando el CUI ya existe: se marca ese campo en el formulario
        if (respuesta.StatusCode == HttpStatusCode.Conflict && errores.Count == 0 && !string.IsNullOrWhiteSpace(detalle))
            errores[nameof(Cliente.CUI)] = new[] { detalle };

        var generico = respuesta.StatusCode switch
        {
            HttpStatusCode.NotFound => "El cliente no existe (quizá ya fue eliminado).",
            HttpStatusCode.BadRequest => "La API rechazó los datos enviados. Revisa los campos marcados.",
            HttpStatusCode.Conflict => "Ya existe un cliente con esos datos.",
            HttpStatusCode.InternalServerError => "Error interno en la API. Revisa que SQL Server esté funcionando.",
            _ => $"La API respondió con error {(int)respuesta.StatusCode} ({respuesta.ReasonPhrase})."
        };

        throw new ApiException(string.IsNullOrWhiteSpace(detalle) ? generico : detalle, respuesta.StatusCode, errores);
    }

    /// <summary>
    /// Lee los formatos de error de la API:
    ///   { "mensaje": "..." }                          (404, 409, 400 del controlador)
    ///   { "title": "...", "errors": { "CUI": [..] } } (400 de validación automática)
    /// </summary>
    private static async Task<(string Detalle, Dictionary<string, string[]> Errores)> LeerErrorAsync(HttpResponseMessage respuesta)
    {
        var errores = new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase);
        try
        {
            var texto = await respuesta.Content.ReadAsStringAsync();
            if (string.IsNullOrWhiteSpace(texto)) return (string.Empty, errores);

            using var doc = JsonDocument.Parse(texto);
            var raiz = doc.RootElement;
            if (raiz.ValueKind != JsonValueKind.Object) return (string.Empty, errores);

            if (raiz.TryGetProperty("errors", out var errs) && errs.ValueKind == JsonValueKind.Object)
            {
                foreach (var e in errs.EnumerateObject())
                {
                    var mensajes = e.Value.ValueKind == JsonValueKind.Array
                        ? e.Value.EnumerateArray().Select(v => v.ToString()).ToArray()
                        : new[] { e.Value.ToString() };
                    // "$.Fecha_Nacimiento" (error de formato JSON) -> "Fecha_Nacimiento"
                    var campo = e.Name.TrimStart('$', '.');
                    errores[campo] = mensajes;
                }
            }

            foreach (var nombre in new[] { "mensaje", "detail" })
            {
                if (raiz.TryGetProperty(nombre, out var valor) && valor.ValueKind == JsonValueKind.String)
                    return (valor.GetString() ?? string.Empty, errores);
            }

            if (errores.Count > 0)
                return (string.Join(" ", errores.Values.SelectMany(m => m)), errores);

            if (raiz.TryGetProperty("title", out var titulo) && titulo.ValueKind == JsonValueKind.String)
                return (titulo.GetString() ?? string.Empty, errores);

            return (string.Empty, errores);
        }
        catch
        {
            return (string.Empty, errores); // La respuesta no era JSON: se usa el mensaje genérico
        }
    }
}

/// <summary>Error de la API con un mensaje amigable y, si aplica, errores por campo.</summary>
public class ApiException : Exception
{
    public HttpStatusCode? StatusCode { get; }

    /// <summary>Errores por campo (clave = nombre de la propiedad, ej. "CUI").</summary>
    public IReadOnlyDictionary<string, string[]> Errores { get; }

    public ApiException(string mensaje, HttpStatusCode? statusCode = null,
        IReadOnlyDictionary<string, string[]>? errores = null) : base(mensaje)
    {
        StatusCode = statusCode;
        Errores = errores ?? new Dictionary<string, string[]>();
    }
}
