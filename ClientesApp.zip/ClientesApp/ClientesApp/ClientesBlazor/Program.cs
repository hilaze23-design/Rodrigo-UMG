using ClientesBlazor.Components;
using ClientesBlazor.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

// ---------------------------------------------------------------------------
// HttpClient que consume la API "ClientesApi" (Tarea .NET).
// La URL se configura en appsettings.json -> ApiSettings:BaseUrl
// ---------------------------------------------------------------------------
var apiBaseUrl = builder.Configuration["ApiSettings:BaseUrl"]
    ?? throw new InvalidOperationException("Falta 'ApiSettings:BaseUrl' en appsettings.json");
if (!apiBaseUrl.EndsWith('/')) apiBaseUrl += "/";

builder.Services.AddHttpClient<ClienteService>(client =>
{
    client.BaseAddress = new Uri(apiBaseUrl);
    client.Timeout = TimeSpan.FromSeconds(30);
})
.ConfigurePrimaryHttpMessageHandler(() =>
{
    var handler = new HttpClientHandler();

    // Solo en desarrollo: si la API corre en https://localhost con el certificado de desarrollo
    // de .NET y no está marcado como confiable, se acepta igual para evitar errores SSL.
    if (builder.Environment.IsDevelopment())
    {
        handler.ServerCertificateCustomValidationCallback = (request, cert, chain, errors) =>
            errors == System.Net.Security.SslPolicyErrors.None
            || request.RequestUri?.IsLoopback == true;
    }

    return handler;
});

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    app.UseHsts();
}
app.UseStatusCodePagesWithReExecute("/not-found", createScopeForStatusCodePages: true);
app.UseHttpsRedirection();

app.UseAntiforgery();

app.MapStaticAssets();
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
