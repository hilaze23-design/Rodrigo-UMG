using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ClientesBlazor.Models;

/// <summary>
/// Cliente tal como lo expone la API (ClientesApi/Models/Cliente.cs).
/// Los nombres de las propiedades son IDÉNTICOS a los de la API (Id_cliente, CUI, NIT, ...)
/// y las validaciones son las mismas, para que el formulario avise antes de enviar.
/// </summary>
public class Cliente
{
    public int Id_cliente { get; set; }

    [Required(ErrorMessage = "El CUI es obligatorio.")]
    [RegularExpression(@"^\d{13}$", ErrorMessage = "El CUI debe tener exactamente 13 dígitos numéricos.")]
    public string CUI { get; set; } = string.Empty;

    [Required(ErrorMessage = "El NIT es obligatorio.")]
    [StringLength(15, ErrorMessage = "El NIT no puede exceder 15 caracteres.")]
    [RegularExpression(@"^(\d{1,13}-?[\dKk]|CF|cf)$", ErrorMessage = "El NIT no tiene un formato válido (ej.: 1234567-8, 12345678K o CF).")]
    public string NIT { get; set; } = string.Empty;

    [Required(ErrorMessage = "Los nombres son obligatorios.")]
    [StringLength(100, ErrorMessage = "Los nombres no pueden exceder 100 caracteres.")]
    public string Nombres { get; set; } = string.Empty;

    [Required(ErrorMessage = "Los apellidos son obligatorios.")]
    [StringLength(100, ErrorMessage = "Los apellidos no pueden exceder 100 caracteres.")]
    public string Apellidos { get; set; } = string.Empty;

    [Required(ErrorMessage = "La dirección es obligatoria.")]
    [StringLength(200, ErrorMessage = "La dirección no puede exceder 200 caracteres.")]
    public string Direccion { get; set; } = string.Empty;

    [Required(ErrorMessage = "El teléfono es obligatorio.")]
    [StringLength(20, ErrorMessage = "El teléfono no puede exceder 20 caracteres.")]
    [RegularExpression(@"^(\+502\s?)?\d{4}-?\d{4}$", ErrorMessage = "El teléfono debe tener 8 dígitos (ej.: 55551234, 5555-1234 o +502 55551234).")]
    public string Telefono { get; set; } = string.Empty;

    /// <summary>
    /// Nullable solo en Blazor para que el campo aparezca vacío al crear un cliente.
    /// [Required] garantiza que nunca se envíe vacío a la API.
    /// </summary>
    [Required(ErrorMessage = "La fecha de nacimiento es obligatoria.")]
    [FechaNacimientoValida]
    public DateOnly? Fecha_Nacimiento { get; set; }

    [JsonIgnore]
    public string NombreCompleto => $"{Nombres} {Apellidos}";

    /// <summary>Crea una copia para editar en el modal sin modificar la fila de la tabla.</summary>
    public Cliente Clonar() => (Cliente)MemberwiseClone();
}

/// <summary>Misma regla que la API: entre 1900-01-01 y la fecha actual.</summary>
public class FechaNacimientoValidaAttribute : ValidationAttribute
{
    public FechaNacimientoValidaAttribute()
        : base("La fecha de nacimiento debe estar entre 1900-01-01 y la fecha actual.") { }

    public override bool IsValid(object? value)
    {
        if (value is not DateOnly fecha) return true; // [Required] se encarga del vacío
        var hoy = DateOnly.FromDateTime(DateTime.Today);
        return fecha >= new DateOnly(1900, 1, 1) && fecha <= hoy;
    }
}
