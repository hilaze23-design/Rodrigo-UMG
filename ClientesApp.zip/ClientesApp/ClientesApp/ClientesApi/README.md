# API REST de Clientes — .NET 10 + Entity Framework Core + SQL Server

API para administrar clientes (CRUD completo) construida con ASP.NET Core Web API en **.NET 10**, **Entity Framework Core 10** y **SQL Server**.

## Estructura

```
ClientesApi.sln
ClientesApi/
├── Controllers/
│   └── ClientesController.cs   ← GET, GET por Id, POST, PUT, DELETE
├── Data/
│   └── AppDbContext.cs         ← DbContext de Entity Framework Core
├── Models/
│   └── Cliente.cs              ← Modelo con validaciones
├── Properties/launchSettings.json
├── appsettings.json            ← Cadena de conexión
├── ClientesApi.http            ← Peticiones de prueba
└── Program.cs                  ← Configuración (EF Core, Swagger)
Database/
└── ClientesDB.sql              ← Script SQL opcional
```

## Requisitos

- SDK de .NET 10 (Visual Studio 2026 o `dotnet --version` ≥ 10)
- SQL Server (Developer, Express o LocalDB)

## Cómo ejecutarlo

1. **Revisa la cadena de conexión** en `ClientesApi/appsettings.json`. Por defecto usa la instancia predeterminada con autenticación de Windows:

   ```json
   "ClientesDB": "Server=localhost;Database=ClientesDB;Trusted_Connection=True;TrustServerCertificate=True;MultipleActiveResultSets=True"
   ```

   Cambia solo el valor de `Server` según tu instalación (en el JSON la barra invertida va doble `\\`):

   | Tu SQL Server                    | Valor de `Server`            |
   |----------------------------------|------------------------------|
   | Developer / instancia por defecto| `localhost`                  |
   | SQL Server Express               | `localhost\\SQLEXPRESS`      |
   | LocalDB (viene con Visual Studio)| `(localdb)\\MSSQLLocalDB`    |

   Con usuario y contraseña de SQL: `Server=localhost;Database=ClientesDB;User Id=sa;Password=TU_CLAVE;TrustServerCertificate=True`

2. **Ejecuta** el proyecto:
   - Visual Studio: abre `ClientesApi.sln` y presiona **F5**.
   - Terminal: `dotnet run --project ClientesApi`

3. Se abre **Swagger** en `http://localhost:5062/swagger` para probar todos los endpoints.

La base de datos `ClientesDB` y la tabla `Clientes` se crean **automáticamente** la primera vez que arranca la API. No hace falta ejecutar migraciones ni el script SQL.

## Endpoints

| Método | Ruta                 | Descripción                         | Respuestas              |
|--------|----------------------|-------------------------------------|-------------------------|
| GET    | `/api/Clientes`      | Listado completo de clientes        | 200                     |
| GET    | `/api/Clientes/{id}` | Obtener un cliente por Id           | 200, 404                |
| POST   | `/api/Clientes`      | Registrar un nuevo cliente          | 201, 400, 409           |
| PUT    | `/api/Clientes/{id}` | Actualizar un cliente existente     | 204, 400, 404, 409      |
| DELETE | `/api/Clientes/{id}` | Eliminar un cliente                 | 204, 404                |

### Ejemplo de cuerpo (POST / PUT)

```json
{
  "CUI": "1234567890101",
  "NIT": "1234567-8",
  "Nombres": "Juan Carlos",
  "Apellidos": "Pérez López",
  "Direccion": "5a. Avenida 10-20, Zona 1, Ciudad de Guatemala",
  "Telefono": "5555-1234",
  "Fecha_Nacimiento": "1995-06-15"
}
```

`Id_cliente` lo genera la base de datos (IDENTITY). En el PUT puedes enviarlo o no; si lo envías debe coincidir con el `{id}` de la ruta.

### Validaciones

- **CUI**: exactamente 13 dígitos y único (409 si ya existe).
- **NIT**: formato `1234567-8`, `12345678K` o `CF`.
- **Nombres / Apellidos**: obligatorios, máximo 100 caracteres.
- **Dirección**: obligatoria, máximo 200 caracteres.
- **Teléfono**: 8 dígitos (`55551234`, `5555-1234` o `+502 55551234`).
- **Fecha_Nacimiento**: formato `yyyy-MM-dd`, entre 1900-01-01 y hoy.

## Usar migraciones en lugar de creación automática (opcional)

Si tu catedrático pide migraciones:

1. En `Program.cs` elimina el bloque que llama a `db.Database.EnsureCreated()`.
2. Si la base ya fue creada por la API, bórrala primero.
3. En la **Consola del Administrador de paquetes** de Visual Studio:
   ```
   Add-Migration Inicial
   Update-Database
   ```
   o en terminal (requiere `dotnet tool install --global dotnet-ef`):
   ```
   dotnet ef migrations add Inicial --project ClientesApi
   dotnet ef database update --project ClientesApi
   ```

## Solución de problemas

- **"A network-related or instance-specific error"** al iniciar: el valor de `Server` no corresponde a tu instancia o el servicio de SQL Server está detenido. Revisa la tabla del paso 1.
- **"Login failed for user"**: usa usuario/contraseña de SQL o da permisos a tu usuario de Windows.
